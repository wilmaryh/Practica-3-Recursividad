public static long factorialCola(int n) {
    return factorialColaAux(n, 1);
}

private static long factorialColaAux(int n, long acumulado) {
    if (n <= 1) {
        return acumulado;
    }
    return factorialColaAux(n - 1, acumulado * n);
}

void main() {
}